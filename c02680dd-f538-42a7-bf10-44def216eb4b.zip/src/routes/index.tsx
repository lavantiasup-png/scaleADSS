import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import logoAsset from "@/assets/scaleads-logo.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ScaleAds Agency — TikTok Ads Scaling Methods 2026" },
      {
        name: "description",
        content:
          "Formation TikTok Ads 100% Darija & pratique — Testing, Mid Scale, Hard Scale. Maîtrisez les stratégies de scaling utilisées par les marques performantes.",
      },
      { property: "og:title", content: "ScaleAds Agency — TikTok Ads Scaling Methods 2026" },
      {
        property: "og:description",
        content:
          "Formation TikTok Ads 100% Darija & pratique — Testing, Mid Scale, Hard Scale.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Logo() {
  return (
    <img
      src={logoAsset.url}
      alt="ScaleAds Agency"
      className="h-8 w-auto sm:h-9"
    />
  );
}

function Pill({ children, dot = "green" }: { children: React.ReactNode; dot?: "green" | "yellow" }) {
  const dotColor = dot === "green" ? "bg-emerald-400" : "bg-yellow-400";
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-[#0a1350]/80 px-3.5 py-2 text-xs font-medium text-white shadow-sm">
      <span className={`h-2 w-2 rounded-full ${dotColor}`} />
      {children}
    </span>
  );
}

function LightPill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-medium text-slate-700 shadow-sm">
      <span className="h-2 w-2 rounded-full bg-emerald-500" />
      {children}
    </span>
  );
}

function ScriptWord({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={`italic text-[color:var(--brand-accent)] ${className ?? ""}`}
      style={{
        fontFamily: '"Brush Script MT", "Segoe Script", "Lucida Handwriting", cursive',
        fontWeight: 400,
      }}
    >
      {children}
    </span>
  );
}

function VideoCard({
  num,
  title,
  desc,
}: {
  num: string;
  title: string;
  desc: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_2px_8px_rgba(15,23,42,0.04)] sm:p-6">
      <div className="flex flex-col gap-1 sm:flex-row sm:gap-3">
        <div className="flex shrink-0 items-center gap-2">
          <span className="text-[color:var(--brand-accent)]">✦</span>
          <span className="font-semibold text-[color:var(--brand-accent)]">
            Vidéo {num} :
          </span>
        </div>
        <div className="min-w-0">
          <h3 className="font-bold text-slate-900">{title}</h3>
          <p className="mt-1 text-sm leading-relaxed text-slate-500">{desc}</p>
        </div>
      </div>
    </div>
  );
}

function ResultCard() {
  return (
    <div className="aspect-[3/4] w-full overflow-hidden rounded-2xl bg-gradient-to-b from-sky-200 to-sky-100 shadow-lg">
      <svg viewBox="0 0 300 400" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="sky" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#bfe3f7" />
            <stop offset="1" stopColor="#e8f4fb" />
          </linearGradient>
        </defs>
        <rect width="300" height="400" fill="url(#sky)" />
        <ellipse cx="90" cy="110" rx="55" ry="20" fill="#ffffff" />
        <ellipse cx="120" cy="100" rx="35" ry="16" fill="#ffffff" />
        <path d="M0 300 Q75 240 150 280 T300 270 L300 400 L0 400 Z" fill="#7cb342" />
        <path d="M0 340 Q75 300 150 330 T300 320 L300 400 L0 400 Z" fill="#558b2f" />
      </svg>
    </div>
  );
}

function Index() {
  const [agreed, setAgreed] = useState(false);

  return (
    <main className="min-h-screen bg-white text-slate-900">
      {/* HERO */}
      <section className="bg-[color:var(--brand-navy)] px-4 pb-10 pt-4 sm:px-6 sm:pt-6">
        <div className="mx-auto max-w-5xl">
          {/* Nav */}
          <nav className="mx-auto flex max-w-3xl items-center justify-between rounded-2xl border border-white/10 bg-gradient-to-r from-[#0a1350] to-[#1a2ba8] px-4 py-3 shadow-lg sm:px-6">
            <Logo />
            <div className="flex items-center gap-6 text-sm text-white/90">
              <a href="#avis" className="hover:text-white">Avis</a>
              <a href="#formation" className="hover:text-white">Formation</a>
            </div>
          </nav>

          {/* Title */}
          <h1 className="mt-8 text-center text-4xl font-light leading-tight text-white sm:mt-10 sm:text-5xl md:text-6xl">
            Tiktok Ads <span className="font-bold">Scaling</span>
            <br />
            <span className="font-bold">Methods</span>{" "}
            <span className="relative inline-block">
              <span className="font-bold">2026</span>
              <svg
                viewBox="0 0 120 12"
                className="absolute left-1/2 top-full mt-1 h-2.5 w-28 -translate-x-1/2 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              >
                <path d="M2 6 Q 30 1 60 6 T 118 6" />
                <path d="M100 3 L118 6 L102 10" />
              </svg>
            </span>
          </h1>

          {/* Video */}
          <div className="mx-auto mt-8 aspect-video w-full max-w-3xl overflow-hidden rounded-2xl bg-slate-100 shadow-2xl sm:mt-10">
            <iframe
              src="https://player.vimeo.com/video/1212901180?h=dba227ebe1&badge=0&autopause=0&player_id=0&app_id=58479"
              allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media"
              title="ScaleAds TikTok Ads Scaling Methods"
              className="h-full w-full border-0"
            />
          </div>

          {/* Hero badges */}
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Pill>100% Darija</Pill>
            <Pill>Formation 100% Pratique</Pill>
          </div>
        </div>
      </section>

      {/* CURRICULUM */}
      <section id="formation" className="bg-white px-4 py-14 sm:px-6 sm:py-20">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-center text-2xl font-bold text-slate-900 sm:text-3xl">
            Explorez le contenu de votre
            <br />
            <ScriptWord className="text-3xl sm:text-4xl">Formation</ScriptWord>
          </h2>

          <div className="mt-8 space-y-4">
            <VideoCard
              num="1"
              title="Testing Phase METHOD EXPLAINING + PDF ( ROADMAPS )"
              desc="How to Setup your first Creatives test campaign - and data analysis"
            />
            <VideoCard
              num="2"
              title={'Mid Scale METHOD " MID SCALE " EXPLAINING + PDF ( ROADMAPS )'}
              desc="How to start Scaling gradually after finding our Winning Creatives"
            />
            <VideoCard
              num="3"
              title={'HARD Scale METHOD " HARD SCALE " EXPLAINING + PDF ( ROADMAPS )'}
              desc={
                '" Here where the magic start happening " How to surf with our winning creatives to start reaching 100 - 200 order Per day, explainification of our Winning Methods of hard Scaling ( Cost Cap\'s , Surf Scale, "WIN TIME" Day-parting ... ) to keep Tiktok work as a Machine generating you a Massive Number of Orders Daily'
              }
            />
          </div>

          <div className="mt-10 flex flex-col items-center gap-5">
            <a
              href="#offer"
              className="rounded-xl bg-[color:var(--brand-cta)] px-8 py-3.5 text-sm font-semibold text-white shadow-lg transition hover:bg-[color:var(--brand-cta-hover)]"
            >
              Rejoindre La Formation
            </a>
            <div className="flex flex-col items-center gap-2">
              <LightPill>🚀 Communauté privée 100% gratuite</LightPill>
              <LightPill>💛 Accompagnement personnalisé</LightPill>
              <LightPill>💬 15 jours de consulting offerts</LightPill>
            </div>
          </div>
        </div>
      </section>

      {/* RESULTS */}
      <section id="avis" className="bg-[color:var(--brand-navy)] px-4 py-14 sm:px-6 sm:py-20">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-center text-2xl font-bold leading-tight text-white sm:text-3xl">
            Des résultats&nbsp;
            <br />
            prouvés obtenus avec
            <br />
            <span
              className="text-3xl italic text-[#8ea1ff] sm:text-4xl"
              style={{
                fontFamily:
                  '"Brush Script MT", "Segoe Script", "Lucida Handwriting", cursive',
                fontWeight: 400,
              }}
            >
              Nos Méthodes
            </span>
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-3">
            <ResultCard />
            <ResultCard />
            <ResultCard />
          </div>
        </div>
      </section>

      {/* OFFER */}
      <section id="offer" className="bg-white px-4 py-14 sm:px-6 sm:py-20">
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 md:grid-cols-2 md:gap-12">
          {/* Left */}
          <div className="flex flex-col justify-center">
            <p className="text-lg text-slate-700">Accéder aux</p>
            <h2 className="mt-1 text-3xl font-extrabold text-slate-900 sm:text-4xl">
              Stratégies Exclusives
            </h2>
            <p className="mt-2 font-semibold text-slate-800">
              Votre accès à une méthode complète et éprouvée
            </p>
            <p className="mt-4 text-sm font-semibold text-[color:var(--brand-red)]">
              *Offre à durée limitée
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 sm:gap-3">
              <span className="text-sm text-slate-400 line-through sm:text-base">1000 MAD</span>
              <span className="text-xl font-extrabold text-[color:var(--brand-accent)] sm:text-2xl">
                490 MAD
              </span>
              <span className="ml-auto shrink-0 rounded-full bg-slate-900 px-2.5 py-1 text-[10px] font-medium text-white sm:px-3 sm:py-1.5 sm:text-[11px]">
                Satisfait ou remboursé
              </span>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <LightPill>100% Darija</LightPill>
              <LightPill>Formation 100% Pratique</LightPill>
            </div>

            <p className="mt-5 text-sm text-slate-600">
              Maîtrisez les stratégies de scaling TikTok utilisées par les marques
              performantes, en darija, français et anglais.
            </p>
          </div>

          {/* Right form */}
          <div className="rounded-3xl bg-[color:var(--brand-navy)] p-5 sm:p-7">
            <div className="rounded-lg border border-[color:var(--brand-warning-border)] bg-[color:var(--brand-warning-bg)] p-3 text-xs leading-relaxed text-slate-800">
              <span className="font-semibold">⚠ Attention :</span> Ceci n'est pas un
              service d'agence. Nous ne ferons pas le travail à votre place. C'est une
              formation pour apprendre à scaler vos publicités Tiktok vous-même.
            </div>

            <form
              className="mt-5 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
              }}
            >
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-white/80">
                  Nom complet
                </label>
                <input
                  type="text"
                  placeholder="Votre nom complet"
                  className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-white/40 outline-none focus:border-white/40"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-white/80">
                  Adresse e-mail
                </label>
                <input
                  type="email"
                  placeholder="vous@exemple.com"
                  className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-white/40 outline-none focus:border-white/40"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-white/80">
                  Whatsapp / Téléphone
                </label>
                <input
                  type="tel"
                  placeholder="06XX XX XX XX"
                  className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-white/40 outline-none focus:border-white/40"
                />
              </div>

              <label className="flex items-start gap-2.5 rounded-lg border border-white/10 bg-white/5 p-3 text-xs text-white/80">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-0.5 h-4 w-4 shrink-0 accent-[color:var(--brand-accent)]"
                />
                <span>
                  Je comprends que ceci est une FORMATION avec un investissement de 490
                  MAD.
                </span>
              </label>

              <button
                type="submit"
                className="w-full rounded-xl bg-[color:var(--brand-cta)] px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:bg-[color:var(--brand-cta-hover)]"
              >
                Commencer maintenant
              </button>

              <p className="text-center text-[11px] text-white/60">
                ⓘ Satisfait ou remboursé sous 7 jours.
              </p>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
}
